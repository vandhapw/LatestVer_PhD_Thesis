"""
============================================================
ACADEMIC VISUALIZATION: Agentic AI Pipeline for Predictive
Maintenance in Smart Manufacturing
============================================================
Generates 8 publication-quality figures using matplotlib/seaborn
explaining the complete pipeline process step by step.

Figures:
  1. System architecture overview (6-layer pipeline)
  2. Multi-tier sliding window buffer mechanism
  3. Data flow timeline: Kafka → buffer → triggers
  4. 9-agent sequential orchestration chain
  5. Per-event vs micro-batch vs daily trigger comparison
  6. Classical optimization integration (5 points)
  7. Agent decision flow for a single machine
  8. Pipeline output lifecycle and convergence
============================================================
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import seaborn as sns
import numpy as np
import os

# ── Style Configuration ──
sns.set_theme(style="whitegrid", font_scale=1.1)
plt.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': '#FAFAFA',
    'font.family': 'sans-serif',
    'font.size': 11,
    'axes.titlesize': 14,
    'axes.titleweight': 'bold',
    'figure.titlesize': 16,
    'figure.titleweight': 'bold',
    'savefig.dpi': 200,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.3,
})

COLORS = {
    'ingestion': '#4ECDC4',
    'buffer': '#45B7D1',
    'reasoning': '#F9CA24',
    'agents': '#FF6B6B',
    'action': '#A29BFE',
    'learning': '#FD79A8',
    'optimization': '#6C5CE7',
    'quantum': '#00B894',
    'kafka': '#E17055',
    'per_event': '#FDCB6E',
    'micro_batch': '#A29BFE',
    'daily': '#00B894',
    'bg_light': '#F8F9FA',
}

OUTPUT_DIR = "/home/claude/figures"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def add_fancy_box(ax, xy, width, height, label, sublabel=None,
                  color='#4ECDC4', text_color='white', fontsize=10,
                  alpha=0.9, zorder=2):
    """Draw a rounded box with label."""
    box = FancyBboxPatch(xy, width, height,
                         boxstyle="round,pad=0.02",
                         facecolor=color, edgecolor='white',
                         linewidth=1.5, alpha=alpha, zorder=zorder)
    ax.add_patch(box)
    cx = xy[0] + width / 2
    cy = xy[1] + height / 2
    if sublabel:
        ax.text(cx, cy + 0.015, label, ha='center', va='center',
                fontsize=fontsize, fontweight='bold', color=text_color, zorder=zorder+1)
        ax.text(cx, cy - 0.025, sublabel, ha='center', va='center',
                fontsize=fontsize-2, color=text_color, alpha=0.85, zorder=zorder+1)
    else:
        ax.text(cx, cy, label, ha='center', va='center',
                fontsize=fontsize, fontweight='bold', color=text_color, zorder=zorder+1)


def arrow(ax, start, end, color='#555555', style='->', lw=1.5):
    """Draw arrow between two points."""
    ax.annotate('', xy=end, xytext=start,
                arrowprops=dict(arrowstyle=style, color=color, lw=lw))


# ═══════════════════════════════════════════════
# FIGURE 1: System Architecture Overview
# ═══════════════════════════════════════════════

def fig1_architecture():
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    fig.suptitle('Figure 1: Agentic AI Pipeline Architecture for Smart Manufacturing',
                 fontsize=15, fontweight='bold', y=0.98)
    ax.text(0.5, 0.95, 'Six-layer architecture with 9 LLM agents, 5 classical optimization points,\n'
            'and multi-tier sliding window buffer on real-time Kafka streaming data',
            ha='center', va='center', fontsize=10, color='#666', style='italic')

    layers = [
        ("Layer 1: Data Ingestion", "Kafka Consumer → Multi-Tier Buffer", COLORS['ingestion']),
        ("Layer 2: Reasoning Engine", "Rule-based scoring + Mahalanobis (Opt①)", COLORS['reasoning']),
        ("Layer 3: Agent Orchestration", "9 LLM Agents (sequential pipeline)", COLORS['agents']),
        ("Layer 4: Classical Optimization", "Graph (Opt②) + SA (Opt③) + Consensus (Opt④)", COLORS['optimization']),
        ("Layer 5: Action Layer", "Human-in-the-loop + CMMS/ERP dispatch", COLORS['action']),
        ("Layer 6: Learning Loop", "Threshold tuning via Nelder-Mead (Opt⑤)", COLORS['learning']),
    ]

    y_start = 0.85
    for i, (name, desc, color) in enumerate(layers):
        y = y_start - i * 0.115
        add_fancy_box(ax, (0.08, y - 0.04), 0.84, 0.075, name, desc,
                      color=color, fontsize=11)
        if i < len(layers) - 1:
            arrow(ax, (0.5, y - 0.04), (0.5, y - 0.075), color='#888')

    # Feedback arrow
    ax.annotate('', xy=(0.95, 0.82), xytext=(0.95, 0.24),
                arrowprops=dict(arrowstyle='->', color=COLORS['learning'],
                                lw=2, linestyle='dashed'))
    ax.text(0.97, 0.53, 'Feedback\nLoop', ha='center', va='center',
            fontsize=9, color=COLORS['learning'], rotation=90)

    # Data source
    add_fancy_box(ax, (0.25, 0.05), 0.5, 0.055,
                  "Kafka (10.247.166.188:9092)", "Topic: simulated_digitaltwin_manufactured",
                  color=COLORS['kafka'], fontsize=10)
    arrow(ax, (0.5, 0.105), (0.5, 0.16), color=COLORS['kafka'], lw=2)

    fig.savefig(f"{OUTPUT_DIR}/fig1_architecture.png")
    plt.close()
    print("  [1/8] fig1_architecture.png")


# ═══════════════════════════════════════════════
# FIGURE 2: Multi-Tier Sliding Window Buffer
# ═══════════════════════════════════════════════

def fig2_buffer():
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Figure 2: Multi-Tier Sliding Window Buffer Mechanism',
                 fontsize=15, fontweight='bold')
    fig.text(0.5, 0.93, 'Four buffer tiers run simultaneously per machine, each optimized for a different analysis timescale',
             ha='center', fontsize=10, color='#666', style='italic')

    tiers = [
        ("Tier 1: Spike Detection", 15, "1 min", "Per-event z-score", COLORS['per_event']),
        ("Tier 2: Trend Detection", 120, "1 min", "Micro-batch LSTM/LLM", COLORS['micro_batch']),
        ("Tier 3: Pattern Recognition", 288, "5 min avg", "Daily GNN/Correlation", COLORS['daily']),
        ("Tier 4: Baseline Profiling", 336, "1 hr avg", "Daily threshold tuning", COLORS['learning']),
    ]

    for idx, (title, size, sampling, usage, color) in enumerate(tiers):
        ax = axes[idx // 2][idx % 2]

        # Simulate buffer filling over time
        np.random.seed(42 + idx)
        if idx < 2:
            t = np.arange(min(size * 3, 400))
            signal = 72 + np.cumsum(np.random.randn(len(t)) * 0.3)
        else:
            t = np.arange(min(size * 2, 700))
            signal = 72 + np.cumsum(np.random.randn(len(t)) * 0.15)

        # Show the sliding window
        window_start = max(0, len(t) - size)
        inside = signal[window_start:]
        outside = signal[:window_start]

        if len(outside) > 0:
            ax.plot(range(len(outside)), outside, color='#CCCCCC', lw=0.8, alpha=0.5)
        ax.plot(range(len(outside), len(t)), inside, color=color, lw=1.5)

        # Highlight window region
        ax.axvspan(window_start, len(t), alpha=0.08, color=color)
        ax.axvline(window_start, color=color, lw=1.5, linestyle='--', alpha=0.6)

        # Annotations
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.set_xlabel('Data points (time →)', fontsize=9)
        ax.set_ylabel('Sensor value', fontsize=9)

        info = f"Window = {size} points\nSampling = {sampling}\nUsage = {usage}"
        ax.text(0.98, 0.97, info, transform=ax.transAxes, fontsize=8,
                va='top', ha='right', bbox=dict(boxstyle='round,pad=0.4',
                facecolor=color, alpha=0.15, edgecolor=color))

        if len(outside) > 0:
            ax.text(window_start / 2, signal[0], 'Dropped\n(oldest)',
                    ha='center', fontsize=8, color='#999', style='italic')

    plt.tight_layout(rect=[0, 0, 1, 0.91])
    fig.savefig(f"{OUTPUT_DIR}/fig2_buffer_mechanism.png")
    plt.close()
    print("  [2/8] fig2_buffer_mechanism.png")


# ═══════════════════════════════════════════════
# FIGURE 3: Data Flow Timeline
# ═══════════════════════════════════════════════

def fig3_timeline():
    fig, ax = plt.subplots(figsize=(16, 7))
    fig.suptitle('Figure 3: Data Flow Timeline — Kafka to Agent Triggers',
                 fontsize=15, fontweight='bold')

    # Time axis (minutes)
    t = np.arange(0, 1500)

    # Kafka events (50 machines every ~60 seconds)
    kafka_events = np.zeros(len(t))
    for i in range(0, len(t), 1):
        kafka_events[i] = 50  # 50 events per minute

    # Buffer accumulation per machine
    buffer_fill = np.minimum(t, 120)

    # Micro-batch triggers (every 10 minutes = 600 seconds)
    micro_times = np.arange(10, 1500, 10)  # every 10 minutes

    # Daily trigger
    daily_time = 1440  # 24 hours

    # Plot
    ax2 = ax.twinx()

    # Buffer fill
    ax.fill_between(t, 0, buffer_fill, alpha=0.2, color=COLORS['buffer'], label='Tier 2 buffer fill (per machine)')
    ax.plot(t, buffer_fill, color=COLORS['buffer'], lw=2)
    ax.axhline(120, color=COLORS['buffer'], lw=1, linestyle=':', alpha=0.5)
    ax.text(50, 122, 'Tier 2 full (120 points = 2 hours)', fontsize=8, color=COLORS['buffer'])

    # Micro-batch markers
    for mt in micro_times:
        if mt < 1500:
            ax.axvline(mt, color=COLORS['micro_batch'], lw=0.8, alpha=0.3)
    ax.scatter(micro_times[micro_times < 1500], [115]*len(micro_times[micro_times < 1500]),
               color=COLORS['micro_batch'], s=30, zorder=5, label='Micro-batch trigger (every 10 min)')

    # Daily trigger
    if daily_time < 1500:
        ax.axvline(daily_time, color=COLORS['daily'], lw=3, alpha=0.5)
        ax.text(daily_time + 10, 60, 'Daily\ntrigger', fontsize=10,
                fontweight='bold', color=COLORS['daily'])

    # Cumulative events on right axis
    cumulative = np.cumsum(kafka_events)
    ax2.plot(t, cumulative, color=COLORS['kafka'], lw=1.5, alpha=0.6, linestyle='--')
    ax2.set_ylabel('Cumulative Kafka events', color=COLORS['kafka'], fontsize=11)
    ax2.tick_params(axis='y', labelcolor=COLORS['kafka'])

    ax.set_xlabel('Time (minutes from start)', fontsize=12)
    ax.set_ylabel('Buffer occupancy (data points per machine)', fontsize=11)
    ax.legend(loc='upper left', fontsize=9)
    ax.set_xlim(0, 1500)
    ax.set_ylim(0, 140)

    # Phase annotations
    phases = [
        (0, 120, 'Phase 1: Buffer accumulating', '#FFF3CD'),
        (120, 1440, 'Phase 2: Steady-state streaming', '#D4EDDA'),
        (1440, 1500, 'Phase 3:\nDaily', '#CCE5FF'),
    ]
    for start, end, label, color in phases:
        ax.axvspan(start, min(end, 1500), alpha=0.1, color=color)
        cx = (start + min(end, 1500)) / 2
        ax.text(cx, 5, label, ha='center', fontsize=8, style='italic', color='#555')

    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/fig3_data_flow_timeline.png")
    plt.close()
    print("  [3/8] fig3_data_flow_timeline.png")


# ═══════════════════════════════════════════════
# FIGURE 4: 9-Agent Sequential Orchestration
# ═══════════════════════════════════════════════

def fig4_agents():
    fig, ax = plt.subplots(figsize=(16, 9))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    fig.suptitle('Figure 4: Nine-Agent Sequential Orchestration Pipeline',
                 fontsize=15, fontweight='bold', y=0.98)
    ax.text(0.5, 0.95, 'Each agent receives the output of the previous agent as input (chain-of-thought reasoning)',
            ha='center', fontsize=10, color='#666', style='italic')

    agents = [
        ("①", "Monitoring\nAgent", "risk_level,\nanomaly_type,\nconfidence", "Per sensor\n+ trend data", "#E17055"),
        ("②", "Diagnosis\nAgent", "probable_cause,\naffected_component,\nurgency_hours", "Sensor +\nmonitoring\nresult", "#FDCB6E"),
        ("③", "Planning\nAgent", "action,\npriority,\nnotify_supervisor", "Diagnosis +\nrisk score", "#6C5CE7"),
        ("④", "Reporting\nAgent", "Bahasa Indonesia\nalert text", "Diagnosis +\nplanning", "#00B894"),
        ("⑤", "Correlation\nAgent", "clusters,\npropagation_risk,\ncascade_warning", "All machines +\ngraph topology", "#0984E3"),
        ("⑥", "Explainability\nAgent", "top_feature,\ndistance_to_severity,\nwhat_if", "Sensor +\nthresholds", "#E84393"),
        ("⑦", "Consensus\nAgent", "agreed_risk,\nagreement_ratio,\nreliability_score", "Monitoring +\ndiagnosis +\nplanning", "#636E72"),
        ("⑧", "Scheduling\nAgent", "schedule[],\ntotal_downtime,\npriority", "SA results +\nall machines", "#00CEC9"),
        ("⑨", "Pattern\nLearning", "patterns[],\nnovel_count,\nmodel_update", "24h trends +\nall machines", "#FD79A8"),
    ]

    # Micro-batch agents (top row): 1-4, 6, 7
    micro_agents = [0, 1, 2, 3, 5, 6]
    daily_agents = [4, 7, 8]

    # Section labels
    ax.text(0.5, 0.88, 'MICRO-BATCH TRIGGER (every 10 minutes) — per machine with signal',
            ha='center', fontsize=11, fontweight='bold', color=COLORS['micro_batch'],
            bbox=dict(boxstyle='round', facecolor=COLORS['micro_batch'], alpha=0.1))

    # Draw micro-batch agents in 2 rows of 3
    for row_idx, batch_start in enumerate([0, 3]):
        batch_end = min(batch_start + 3, len(micro_agents))
        row_agents = micro_agents[batch_start:batch_end]
        y = 0.72 - row_idx * 0.22

        for col, agent_idx in enumerate(row_agents):
            num, name, output, inp, color = agents[agent_idx]
            x = 0.08 + col * 0.32

            # Agent box
            box = FancyBboxPatch((x, y - 0.07), 0.26, 0.14,
                                 boxstyle="round,pad=0.01",
                                 facecolor=color, alpha=0.85,
                                 edgecolor='white', linewidth=1.5)
            ax.add_patch(box)

            # Agent number and name
            ax.text(x + 0.13, y + 0.05, f"{num} {name}", ha='center', va='center',
                    fontsize=10, fontweight='bold', color='white')

            # Input label (above)
            ax.text(x + 0.13, y + 0.10, f"IN: {inp}", ha='center', va='center',
                    fontsize=7, color='#555',
                    bbox=dict(boxstyle='round,pad=0.2', facecolor='#F0F0F0', alpha=0.8))

            # Output label (below)
            ax.text(x + 0.13, y - 0.10, f"OUT: {output}", ha='center', va='top',
                    fontsize=7, color='#333',
                    bbox=dict(boxstyle='round,pad=0.2', facecolor='#FFF9C4', alpha=0.8))

            # Arrow to next
            if col < len(row_agents) - 1:
                arrow(ax, (x + 0.26, y), (x + 0.32, y), color='#888')

        # Arrow between rows
        if row_idx == 0 and len(micro_agents) > 3:
            arrow(ax, (0.5, y - 0.07), (0.5, y - 0.15), color='#888')

    # Daily agents section
    ax.text(0.5, 0.30, 'SCHEDULED DAILY TRIGGER (every 24 hours) — all 50 machines',
            ha='center', fontsize=11, fontweight='bold', color=COLORS['daily'],
            bbox=dict(boxstyle='round', facecolor=COLORS['daily'], alpha=0.1))

    for col, agent_idx in enumerate(daily_agents):
        num, name, output, inp, color = agents[agent_idx]
        x = 0.08 + col * 0.32
        y = 0.17

        box = FancyBboxPatch((x, y - 0.07), 0.26, 0.14,
                             boxstyle="round,pad=0.01",
                             facecolor=color, alpha=0.85,
                             edgecolor='white', linewidth=1.5)
        ax.add_patch(box)
        ax.text(x + 0.13, y + 0.05, f"{num} {name}", ha='center', va='center',
                fontsize=10, fontweight='bold', color='white')
        ax.text(x + 0.13, y - 0.10, f"OUT: {output}", ha='center', va='top',
                fontsize=7, color='#333',
                bbox=dict(boxstyle='round,pad=0.2', facecolor='#E8F5E9', alpha=0.8))

        if col < len(daily_agents) - 1:
            arrow(ax, (x + 0.26, y), (x + 0.32, y), color='#888')

    fig.savefig(f"{OUTPUT_DIR}/fig4_agent_orchestration.png")
    plt.close()
    print("  [4/8] fig4_agent_orchestration.png")


# ═══════════════════════════════════════════════
# FIGURE 5: Three Trigger Levels Comparison
# ═══════════════════════════════════════════════

def fig5_triggers():
    fig, axes = plt.subplots(1, 3, figsize=(16, 7))
    fig.suptitle('Figure 5: Three Trigger Levels — Response Time vs Analysis Depth Trade-off',
                 fontsize=15, fontweight='bold')

    triggers = [
        {
            'name': 'Per-Event Trigger',
            'interval': 'Every 1 minute',
            'buffer': 'Tier 1 (15 points)',
            'analyses': ['Z-score spike\ndetection', 'Mahalanobis\nmultivariate (Opt①)'],
            'latency': 1,
            'depth': 2,
            'cost': 0,
            'color': COLORS['per_event'],
        },
        {
            'name': 'Micro-Batch Trigger',
            'interval': 'Every 10 minutes',
            'buffer': 'Tier 2 (120 points)',
            'analyses': ['Agent ① Monitor', 'Agent ② Diagnose',
                         'Agent ③ Plan', 'Agent ④ Report',
                         'Agent ⑥ XAI', 'Agent ⑦ Consensus',
                         'Consensus (Opt④)'],
            'latency': 10,
            'depth': 7,
            'cost': 7,
            'color': COLORS['micro_batch'],
        },
        {
            'name': 'Scheduled Daily Trigger',
            'interval': 'Every 24 hours',
            'buffer': 'Tier 3+4 (24h + 14d)',
            'analyses': ['Agent ⑤ Correlation', 'Agent ⑧ Scheduling',
                         'Agent ⑨ Pattern', 'Agent ④ Report',
                         'Graph (Opt②)', 'SA Schedule (Opt③)',
                         'Threshold (Opt⑤)'],
            'latency': 1440,
            'depth': 7,
            'cost': 4,
            'color': COLORS['daily'],
        },
    ]

    for idx, trigger in enumerate(triggers):
        ax = axes[idx]
        analyses = trigger['analyses']
        n = len(analyses)

        # Horizontal bar chart of analyses
        y_pos = np.arange(n)
        colors = [trigger['color']] * n
        # Different shade for optimization vs LLM
        for i, a in enumerate(analyses):
            if 'Opt' in a:
                colors[i] = COLORS['optimization']

        bars = ax.barh(y_pos, [1] * n, color=colors, alpha=0.7, edgecolor='white', height=0.7)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(analyses, fontsize=9)
        ax.set_xlim(0, 1.5)
        ax.set_xticks([])

        ax.set_title(trigger['name'], fontsize=13, fontweight='bold', color=trigger['color'])

        info = f"Interval: {trigger['interval']}\nBuffer: {trigger['buffer']}\nLLM calls: {trigger['cost']}/machine"
        ax.text(1.3, n / 2, info, fontsize=9, va='center',
                bbox=dict(boxstyle='round,pad=0.4', facecolor=trigger['color'], alpha=0.1))

        # Label bars
        for i, bar in enumerate(bars):
            label = "LLM" if 'Opt' not in analyses[i] else "Classical"
            ax.text(0.5, i, label, ha='center', va='center', fontsize=8,
                    fontweight='bold', color='white')

    plt.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(f"{OUTPUT_DIR}/fig5_trigger_comparison.png")
    plt.close()
    print("  [5/8] fig5_trigger_comparison.png")


# ═══════════════════════════════════════════════
# FIGURE 6: Classical Optimization Integration
# ═══════════════════════════════════════════════

def fig6_optimization():
    fig, ax = plt.subplots(figsize=(14, 9))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    fig.suptitle('Figure 6: Five Classical Optimization Integration Points',
                 fontsize=15, fontweight='bold', y=0.98)
    ax.text(0.5, 0.94, 'Each classical algorithm can be replaced by its quantum counterpart',
            ha='center', fontsize=10, color='#666', style='italic')

    points = [
        {
            'num': '①', 'name': 'Mahalanobis Distance',
            'trigger': 'Per-event', 'replaces': 'Z-score (univariate)',
            'quantum': 'VQC (4-qubit)', 'color': COLORS['per_event'],
            'desc': 'Multivariate anomaly:\ncovariance matrix →\nMahalanobis distance'
        },
        {
            'num': '②', 'name': 'Graph Message Passing',
            'trigger': 'Daily', 'replaces': 'LLM correlation guess',
            'quantum': 'QGNN', 'color': COLORS['daily'],
            'desc': 'Inter-machine correlation:\nadjacency × features →\nclusters + propagation risk'
        },
        {
            'num': '③', 'name': 'Simulated Annealing',
            'trigger': 'Daily', 'replaces': 'LLM scheduling guess',
            'quantum': 'QAOA (50-qubit)', 'color': '#0984E3',
            'desc': 'Maintenance scheduling:\n2000 SA iterations →\noptimal machine subset'
        },
        {
            'num': '④', 'name': 'Cosine Similarity Consensus',
            'trigger': 'Micro-batch', 'replaces': 'LLM consensus',
            'quantum': 'Quantum Kernel', 'color': COLORS['micro_batch'],
            'desc': 'Agent validation:\nvectorize outputs →\npairwise cosine sim'
        },
        {
            'num': '⑤', 'name': 'Nelder-Mead Optimizer',
            'trigger': 'Daily', 'replaces': 'Fixed threshold +2°C',
            'quantum': 'Quantum Annealing', 'color': COLORS['learning'],
            'desc': 'Threshold tuning:\n8-dim landscape →\nminimize FP + 2×FN'
        },
    ]

    for i, pt in enumerate(points):
        y = 0.82 - i * 0.16

        # Classical box (left)
        box = FancyBboxPatch((0.05, y - 0.05), 0.35, 0.1,
                             boxstyle="round,pad=0.01",
                             facecolor=pt['color'], alpha=0.8,
                             edgecolor='white', linewidth=1.5)
        ax.add_patch(box)
        ax.text(0.225, y + 0.02, f"Opt {pt['num']}  {pt['name']}",
                ha='center', va='center', fontsize=10, fontweight='bold', color='white')
        ax.text(0.225, y - 0.02, f"Trigger: {pt['trigger']}",
                ha='center', va='center', fontsize=8, color='white', alpha=0.8)

        # Description (middle)
        ax.text(0.55, y, pt['desc'], ha='center', va='center', fontsize=9,
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#F5F5F5', edgecolor='#DDD'))

        # Quantum future (right)
        box_q = FancyBboxPatch((0.72, y - 0.035), 0.22, 0.07,
                               boxstyle="round,pad=0.01",
                               facecolor=COLORS['quantum'], alpha=0.3,
                               edgecolor=COLORS['quantum'], linewidth=1.5,
                               linestyle='dashed')
        ax.add_patch(box_q)
        ax.text(0.83, y, f"→ {pt['quantum']}", ha='center', va='center',
                fontsize=9, color=COLORS['quantum'], fontweight='bold')

        # Arrow classical → quantum
        arrow(ax, (0.68, y), (0.72, y), color='#AAA', style='->', lw=1)

    # Legend
    ax.text(0.225, 0.06, 'Classical (implemented)', ha='center', fontsize=10,
            fontweight='bold', color='#333')
    ax.text(0.83, 0.06, 'Quantum (future swap)', ha='center', fontsize=10,
            fontweight='bold', color=COLORS['quantum'])

    fig.savefig(f"{OUTPUT_DIR}/fig6_optimization_points.png")
    plt.close()
    print("  [6/8] fig6_optimization_points.png")


# ═══════════════════════════════════════════════
# FIGURE 7: Agent Decision Flow for Single Machine
# ═══════════════════════════════════════════════

def fig7_single_machine():
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    fig.suptitle('Figure 7: Agent Decision Flow — Machine M-37 Case Study',
                 fontsize=15, fontweight='bold')

    # LEFT: Sensor data radar chart
    ax1 = fig.add_subplot(121, projection='polar')
    categories = ['Temperature\n(83.4°C)', 'Vibration\n(46.6)', 'Humidity\n(57.2%)',
                  'Pressure\n(3.09)', 'Energy\n(2.10 kWh)']
    values = [83.4/95, 46.6/80, 57.2/78, 3.09/5, 2.1/4.7]  # normalized to crit threshold
    warn_values = [85/95, 65/80, 72/78, 3.5/5, 4.0/4.7]     # warning thresholds

    N = len(categories)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    values += values[:1]
    warn_values += warn_values[:1]
    angles += angles[:1]

    ax1.plot(angles, values, 'o-', linewidth=2, color=COLORS['agents'], label='M-37 sensor values')
    ax1.fill(angles, values, alpha=0.15, color=COLORS['agents'])
    ax1.plot(angles, warn_values, '--', linewidth=1.5, color='#F0A500', alpha=0.7, label='Warning threshold')
    ax1.set_xticks(angles[:-1])
    ax1.set_xticklabels(categories, fontsize=9)
    ax1.set_ylim(0, 1.2)
    ax1.set_title('Sensor Profile (normalized to critical threshold)', fontsize=11, pad=20)
    ax1.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)

    # RIGHT: Agent pipeline waterfall
    ax2 = axes[1]
    agents_flow = [
        ('Reasoning\nEngine', 0.15, 'risk=0.15\nsev=LOW', '#999'),
        ('① Monitoring', None, 'risk=MEDIUM\nanomaly=thermal', COLORS['agents']),
        ('② Diagnosis', None, 'cause=overheating\ncomp=motor', '#FDCB6E'),
        ('③ Planning', None, 'action=inspect\npriority=P3', COLORS['optimization']),
        ('④ Reporting', None, '"Mesin M-37\nmenunjukkan..."', COLORS['daily']),
        ('⑥ XAI', None, 'top=temperature\nΔ1.6°C→MEDIUM', '#E84393'),
        ('⑦ Consensus', None, 'agreed=MEDIUM\nreliability=0.87', '#636E72'),
    ]

    y_positions = np.arange(len(agents_flow))[::-1]
    for i, (name, _, output, color) in enumerate(agents_flow):
        y = y_positions[i]
        bar = ax2.barh(y, 1, color=color, alpha=0.75, edgecolor='white', height=0.7)
        ax2.text(0.02, y, name, ha='left', va='center', fontsize=10, fontweight='bold', color='white')
        ax2.text(1.05, y, output, ha='left', va='center', fontsize=8, color='#333',
                 bbox=dict(boxstyle='round,pad=0.2', facecolor='#F5F5F5', alpha=0.9))

    ax2.set_xlim(0, 2.2)
    ax2.set_yticks([])
    ax2.set_xticks([])
    ax2.set_title('Sequential agent pipeline output', fontsize=11, fontweight='bold')

    # Arrow annotations
    for i in range(len(agents_flow) - 1):
        y_from = y_positions[i] - 0.35
        y_to = y_positions[i + 1] + 0.35
        ax2.annotate('', xy=(0.5, y_to), xytext=(0.5, y_from),
                     arrowprops=dict(arrowstyle='->', color='#AAA', lw=1.5))

    # Highlight: reasoning says LOW but agents say MEDIUM
    ax2.annotate('Rule-based: LOW\nAgents: MEDIUM\n→ Agents detect\nnear-miss!',
                 xy=(1.0, y_positions[0]), xytext=(1.7, y_positions[0] + 1.5),
                 fontsize=9, color=COLORS['agents'], fontweight='bold',
                 arrowprops=dict(arrowstyle='->', color=COLORS['agents'], lw=1.5),
                 bbox=dict(boxstyle='round', facecolor=COLORS['agents'], alpha=0.1))

    plt.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(f"{OUTPUT_DIR}/fig7_single_machine_flow.png")
    plt.close()
    print("  [7/8] fig7_single_machine_flow.png")


# ═══════════════════════════════════════════════
# FIGURE 8: Pipeline Output Lifecycle
# ═══════════════════════════════════════════════

def fig8_lifecycle():
    fig, axes = plt.subplots(2, 1, figsize=(16, 10), gridspec_kw={'height_ratios': [2, 1]})
    fig.suptitle('Figure 8: Pipeline Output Lifecycle and Information Accumulation',
                 fontsize=15, fontweight='bold')

    # TOP: Information richness over time
    ax1 = axes[0]
    hours = np.linspace(0, 48, 500)

    # Per-event: available immediately but shallow
    per_event_info = np.ones_like(hours) * 2
    per_event_info[:10] = np.linspace(0, 2, 10)  # ramp up first 10 points

    # Micro-batch: available at t=10min, grows with buffer
    micro_info = np.zeros_like(hours)
    for i, h in enumerate(hours):
        mins = h * 60
        if mins >= 10:
            buffer_pct = min(1.0, mins / 120)  # Tier 2 fills in 2 hours
            micro_info[i] = 5 + buffer_pct * 3  # 5 base + 3 from trend quality
    micro_info = np.clip(micro_info, 0, 8)

    # Daily: available at t=24h, big jump
    daily_info = np.zeros_like(hours)
    for i, h in enumerate(hours):
        if h >= 24:
            daily_info[i] = 5
        if h >= 48:
            daily_info[i] = 6  # second daily slightly more (learning applied)

    # Total
    total = per_event_info + micro_info + daily_info

    ax1.fill_between(hours, 0, per_event_info, alpha=0.3, color=COLORS['per_event'], label='Per-event (spike + Mahalanobis)')
    ax1.fill_between(hours, per_event_info, per_event_info + micro_info, alpha=0.3,
                     color=COLORS['micro_batch'], label='Micro-batch (6 LLM agents + consensus)')
    ax1.fill_between(hours, per_event_info + micro_info, total, alpha=0.3,
                     color=COLORS['daily'], label='Daily (correlation + scheduling + patterns + threshold opt)')
    ax1.plot(hours, total, color='#333', lw=2, label='Total information richness')

    # Milestone markers
    milestones = [
        (0.17, 'First micro-batch\n(t=10 min)', COLORS['micro_batch']),
        (2.0, 'Tier 2 buffer full\n(t=2 hours)', COLORS['buffer']),
        (24, 'First daily trigger\n(t=24 hours)', COLORS['daily']),
        (48, 'Second daily\n(learning applied)', COLORS['learning']),
    ]
    for h, label, color in milestones:
        if h <= 48:
            ax1.axvline(h, color=color, lw=1.5, linestyle=':', alpha=0.6)
            y_pos = 14 if h < 24 else 16
            ax1.text(h + 0.5, y_pos, label, fontsize=8, color=color, fontweight='bold')

    ax1.set_ylabel('Information richness\n(actionable fields per machine)', fontsize=11)
    ax1.set_xlim(0, 48)
    ax1.legend(loc='upper left', fontsize=9)
    ax1.set_title('Cumulative information accumulation over time', fontsize=12)

    # BOTTOM: Output file generation
    ax2 = axes[1]

    # Micro-batch files every 10 min
    micro_times_h = np.arange(10/60, 48, 10/60)
    ax2.scatter(micro_times_h, [1] * len(micro_times_h),
                color=COLORS['micro_batch'], s=15, alpha=0.6, zorder=5)
    ax2.text(24, 1.3, f'{len(micro_times_h)} microbatch JSON files', ha='center',
             fontsize=9, color=COLORS['micro_batch'])

    # Daily files
    daily_times_h = [24, 48]
    ax2.scatter(daily_times_h, [2] * len(daily_times_h),
                color=COLORS['daily'], s=100, marker='D', zorder=5)
    ax2.text(36, 2.3, '2 daily JSON files', ha='center',
             fontsize=9, color=COLORS['daily'])

    ax2.set_xlabel('Time (hours from start)', fontsize=12)
    ax2.set_ylabel('Output type', fontsize=11)
    ax2.set_yticks([1, 2])
    ax2.set_yticklabels(['microbatch_*.json', 'daily_*.json'], fontsize=10)
    ax2.set_xlim(0, 48)
    ax2.set_ylim(0.5, 3)
    ax2.set_title('Output file generation timeline', fontsize=12)

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(f"{OUTPUT_DIR}/fig8_output_lifecycle.png")
    plt.close()
    print("  [8/8] fig8_output_lifecycle.png")


# ═══════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════

def main():
    print("\n" + "=" * 60)
    print("  Generating 8 Academic Visualization Figures")
    print("  matplotlib + seaborn, publication quality")
    print("=" * 60 + "\n")

    fig1_architecture()
    fig2_buffer()
    fig3_timeline()
    fig4_agents()
    fig5_triggers()
    fig6_optimization()
    fig7_single_machine()
    fig8_lifecycle()

    print(f"\n  All 8 figures saved to {OUTPUT_DIR}/")
    print("=" * 60)


if __name__ == "__main__":
    main()
